﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Web;
using System.Web.Mvc;
using FHP_VO;
using FHP_BM;
using FHP_DL;
using FHP.Help;
using System.Reflection;


namespace FHP.Controllers
{
    public class HomeController : Controller
    {
        EntityHandle entityHandle;       
        string connectionString;

        public ActionResult Index()
        {
            entityHandle = HttpContext.Application["BLObject_Employee"] as EntityHandle;
            connectionString = HttpContext.Application["ConnectionString"] as string;  
          
            entityHandle.EmployeeDatObject = new FileHandingDB(connectionString);
            List<EmployeeData> objList = entityHandle.ReadAllDataData();
           
            cls_XMLHelper xMLHelper = new cls_XMLHelper();
            Session["xmlFilePath"] = Server.MapPath("~/App_Data/Employees.xml");
            Session["xmlHelperObject"] = xMLHelper;

            xMLHelper.StoreEmployeesDataIntoXML(objList, Session["xmlFilePath"] as string);
            return View(objList);
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }
       
        public ActionResult Login()
        {
            //validateUsers.UserDataObject = new ReadUsersDataDB(connectionString);          
            return View();
        }
        [HttpPost]
        public ActionResult Index(User model)
        {
            ValidateUsers validateUsers = new ValidateUsers();
            if (ModelState.IsValid)
            {
                connectionString = "Server=LAPTOP-26NGBJQ5;Database=FHP;Trusted_Connection=True; TrustServerCertificate=True";
                validateUsers.UserDataObject = new ReadUsersDataDB(connectionString);
              
                bool  IsUserExist = validateUsers.isUserPresent(model);
                if (IsUserExist)
                {

                    return RedirectToAction("Index", "Home");

                }
                else
                {
                    model.ErrorMessage = string.Empty;
                    return RedirectToAction("Login", "Home");                    
                }
            }
            return RedirectToAction("Login", "Home");
            
        }


        public ActionResult Views(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return View("Error");
            }

            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            string xmlFilePath = Session["xmlFilePath"] as string;

            if (xmlHelper == null || string.IsNullOrEmpty(xmlFilePath))
            {
                return View("Error");
            }

            List<EmployeeData> employeesList = xmlHelper.ParseEmployeesFromXML(xmlFilePath);
            EmployeeData empToUpdate = employeesList.FirstOrDefault(x => x.SrNo == long.Parse(id));

            if (empToUpdate == null)
            {
                return View("Error");
            }
            ViewData["Action"] = "Update";
            return View("New", empToUpdate);
        }
      
        public ActionResult New()
        {
            ViewBag.Message = "Your application description page.";
            return View();
        }


        [HttpPost]
        public ActionResult New(EmployeeData model)
            {          
            // Create a Record instance
            entityHandle = HttpContext.Application["BLObject_Employee"] as EntityHandle;
            ValueObject_VO Value_object = HttpContext.Application["Object"] as ValueObject_VO;
            connectionString = HttpContext.Application["ConnectionString"] as string;        
            EmployeeData newRecord = new EmployeeData
            {
                SrNo = model.SrNo,
                FirstName = model.FirstName,
                MiddleName = model.MiddleName,
                LastName = model.LastName,
                Prefix = model.Prefix,
                DOB = model.DOB,
                DOJ =model.DOJ,
                CurrentAddress = model.CurrentAddress,
                CurrentCompany = model.CurrentCompany,
                Qualification = model.Qualification,
            };
            Value_object.EmployeeData = newRecord;                
            entityHandle.AddData(model);                   
            return RedirectToAction("Index", "Home");          
        }


        public ActionResult Pagination(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return View("Error");
            }

            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            string xmlFilePath = Session["xmlFilePath"] as string;

            if (xmlHelper == null || string.IsNullOrEmpty(xmlFilePath))
            {
                return View("Error");
            }

            List<EmployeeData> employeesList = xmlHelper.ParseEmployeesFromXML(xmlFilePath);
            EmployeeData empToUpdate = employeesList.FirstOrDefault(x => x.SrNo == long.Parse(id));

            if (empToUpdate == null)
            {
                return View("Error");
            }

            ViewData["Action"] = "View";
            return View("New", empToUpdate);
        }

        public ActionResult Update(string id)
        {
            
            if (string.IsNullOrEmpty(id))
            {
                return View("Error");
            }

            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            string xmlFilePath = Session["xmlFilePath"] as string;

            if (xmlHelper == null || string.IsNullOrEmpty(xmlFilePath))
            {
                return View("Error");
            }

            List<EmployeeData> employeesList = xmlHelper.ParseEmployeesFromXML(xmlFilePath);
            EmployeeData empToUpdate = employeesList.FirstOrDefault(x => x.SrNo == long.Parse(id));

            if (empToUpdate == null)
            {
                return View("Error");
            }
            ViewData["Action"] = "Update";
            return View("New", empToUpdate);
        }
        [HttpPost]
        public ActionResult Update(EmployeeData updatedEmp)
        {
            entityHandle = HttpContext.Application["BLObject_Employee"] as EntityHandle;
            ValueObject_VO Value_object = HttpContext.Application["Object"] as ValueObject_VO;
            connectionString = HttpContext.Application["ConnectionString"] as string;
            EmployeeData newRecord = new EmployeeData
            {
                SrNo = updatedEmp.SrNo,
                FirstName = updatedEmp.FirstName,
                MiddleName = updatedEmp.MiddleName,
                LastName = updatedEmp.LastName,
                Prefix = updatedEmp.Prefix,
                DOB = updatedEmp.DOB,
                DOJ = updatedEmp.DOJ,
                CurrentAddress = updatedEmp.CurrentAddress,
                CurrentCompany = updatedEmp.CurrentCompany,
                Qualification = updatedEmp.Qualification,
            };
            Value_object.EmployeeData = newRecord;
            entityHandle.UpdateData(updatedEmp);
            return RedirectToAction("Index", "Home");          
        }


        [HttpPost]
        public ActionResult Delete(string[] ids)
        {
            bool isUserValid = true;
            EntityHandle entityHandle = HttpContext.Application["BLObject_Employee"] as EntityHandle;
            List<EmployeeData> x = Session["employeeList"] as List<EmployeeData>;
            

            foreach (string serialNo in ids)
            {
                long serial = long.Parse(serialNo);
                EmployeeData empToBeDelete = entityHandle.ReadAllDataData().Find(s => s.SrNo == serial);
                entityHandle.DeleteData(empToBeDelete);
                

            }
            //  return RedirectToAction("Index", "Home");
            if (isUserValid)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false });
            }
        }
        public ActionResult SortAsc(string columnName)
        {
            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            List<EmployeeData> sortedData = xmlHelper.ParseEmployeesFromXML(Session["xmlFilePath"] as string);
            sortedData = sortedData.OrderBy(e => e.GetType().GetProperty(columnName).GetValue(e, null)).ToList();
            //return View("Index", sortedData);
            return Json(sortedData, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Action Method that Sort the data in descending
        /// </summary>
        /// <param name="columnName"> Represents the column based on sorting is to be done </param>
        /// <returns> The sorted data which is to be sent as repsonse to the caller to display the sorted data</returns>
        public ActionResult SortDesc(string columnName)
        {
            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            List<EmployeeData> sortedData = xmlHelper.ParseEmployeesFromXML(Session["xmlFilePath"] as string);
            sortedData = sortedData.OrderByDescending(e => e.GetType().GetProperty(columnName).GetValue(e, null)).ToList();
           // return View("Index",sortedData);
            return Json(sortedData, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ApplyFilter(string[] searchBoxesValues)
        {
            cls_XMLHelper xmlHelper = Session["xmlHelperObject"] as cls_XMLHelper;
            List<EmployeeData> sortedData = xmlHelper.ParseEmployeesFromXML(Session["xmlFilePath"] as string);
            List<EmployeeData> filteredList = new List<EmployeeData>();

            for (int i = 0; i < sortedData.Count; i++)
            {
                bool dataMatched = true;

                for (int j = 0; j < searchBoxesValues.Length; j++)
                {
                    if (!String.IsNullOrEmpty(searchBoxesValues[j]))
                    {
                        string searchString = searchBoxesValues[j].ToLower();

                        string targetString = "";

                        switch (j)
                        {
                            case 0:
                                targetString = sortedData[i].SrNo.ToString();
                                break;
                            case 1:
                                targetString = sortedData[i].Prefix;
                                break;
                            case 2:
                                targetString = sortedData[i].FirstName;
                                break;
                            case 3:
                                targetString = sortedData[i].MiddleName;
                                break;
                            case 4:
                                targetString = sortedData[i].LastName;
                                break;
                            case 5:
                                targetString = sortedData[i].CurrentAddress;
                                break;
                            case 6:
                                targetString = sortedData[i].DOB.ToShortDateString();
                                break;
                            /*case 7:
                                targetString = sortedData[i].Education;*/
                            //break;
                            case 8:
                                targetString = sortedData[i].CurrentCompany;
                                break;
                            case 9:
                                targetString = sortedData[i].DOJ.ToShortDateString().ToString();
                                break;
                        }


                        if (targetString.IndexOf(searchString, StringComparison.OrdinalIgnoreCase) == -1)
                        {
                            dataMatched = false;
                            break;
                        }
                    }
                }

                if (dataMatched)
                {
                    filteredList.Add(sortedData[i]);
                }
            }

            // Return the filtered data as JSON
            return Json(filteredList, JsonRequestBehavior.AllowGet);
        }



        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";
            return View();
        }
    }
}